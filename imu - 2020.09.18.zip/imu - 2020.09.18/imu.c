#include "imu.h"

/*
 * ! ! !
 * ! ! ! please read <<axis_data.h>> file first ! ! !
 * ! ! !
 */


/*
 *reference : https://blog.csdn.net/guanjianhe/article/details/95608801
 *
 *get angle***************************************************
 *get angle***************************************************
 * (1)
 * γ:pit / θ:rol / ψ:yaw
 * The angular representation of the rotation matrix ：
 * (Geographic coordinates are converted to object coordinates)
 * (This is an orthogonal matrix)(The combined rotation order is yaw->pit->row)
 * [		cosγcosψ				cosγsinψ		 -sinγ  ]
 * |sinθsinγcosψ-cosθsinψ	sinθsinγsinψ+cosθcosψ	sinθcosγ|
 * [cosθsinγcosψ+sinθsinψ	cosθsinγsinψ-sinθcosψ	cosθcosγ]
 * 
 * (2)
 * The angular representation of the rotation matrix ：
 * (object coordinates are converted to Geographic coordinates)(T)
 * [cosγcosψ	sinθsinγcosψ-cosθsinψ	cosθsinγcosψ+sinθsinψ]
 * |cosγsinψ	sinθsinγsinψ+cosθcosψ	cosθsinγsinψ-sinθcosψ|
 * [  -sinγ			sinθcosγ					cosθcosγ	 ]
 * 
 * (3)
 * The rotation matrix represented by quaternions：
 * (object coordinates are converted to Geographic coordinates)
 * [1-2(q2q2+q3q3) 	2(q1q2-q0q3)   	2(q0q2+q1q3)  ]
 * | 2(q0q3+q1q2) 	1-2(q1q1+q3q3)	2(q2q3-q0q1)  |
 * [ 2(q1q3-q0q2)  	2(q0q1+q2q3)  	1-2(q1q1+q2q2)]
 * 
 * (4)
 * the result comes from (2) and (3)
 *   -sinγ	 = 2(q1q3-q0q2)   = g0
 *  sinθcosγ = 2(q0q1+q2q3)   = g1 
 *  cosθcosγ = 1-2(q1q1+q2q2) = g2
 *  cosγsinψ = 2(q0q3+q1q2)	  = g3
 *  cosγcosψ = 1-2(q2q2+q3q3) = g4
 * 
 * (5)
 * the result comes from (4)
 * γ(pit) = -arcsin(g0)
 * θ(row) =  arctan(g1/g2)
 * ψ(yaw) =  arctan(g3/g4)
 * 
 * 
 **Quaternion update*******************************************
 **Quaternion update*******************************************
 * reference : take the derivative of [Q = cos(θ/2) + n*sin(θ/2) (Quaternion triangular form)]
 * [q0]		[q0]			[-wxq1-wyq2-wzq3]
 * |q1|  = 	|q1|  +  1/2*dt*|+wxq0-wyq3+wzq2|
 * |q2|		|q2|			|+wxq3+wyq0-wzq1|
 * [q3]		[q3]			[-wxq2+wyq1+wzq0]
 * 
 * 
 **gyr adjust**************************************************
 **gyr adjust**************************************************
 * The update of quaternion has angular velocity integral part, Therefore, there is the phenomenon of elegance.
 * then We use the accelerometer to correct the gyroscope data;
 * Gravity in geographical coordinates is converted to object coordinates:
 * according to The rotation matrix represented by quaternions
 * [qaccx] 		[1-2(q2q2+q3q3) 	2(q1q2-q0q3)   	2(q0q2+q1q3)  ][0]		[ 2(q0q2+q1q3) ]
 * |qaccy|	=	| 2(q0q3+q1q2) 		1-2(q1q1+q3q3)	2(q2q3-q0q1)  ||0|	=	| 2(q2q3-q0q1) |
 * [qaccz]		[ 2(q1q3-q0q2)  	2(q0q1+q2q3)  	1-2(q2q2+q1q1)][1]		[1-2(q2q2+q1q1)]
 *
 * then the right acceleration is acc from sensor and the qacc is drift
 * You get the error by taking the cross product
 * [errx]	[accx]	[qaccx]		[accy*qaccz - accz*qaccy]
 * |erry| = |accy|×	|qaccy| = 	|accz*qaccx - accx*qaccz|
 * [errz]	[accz]	[qaccz]		[accx*qaccy - accy*qaccx]
 * 
 * Complementary filter
 */


#define G_KP	5.0f
#define G_KI	0.1f


imu_t imu = {1,0,0,0, 0,0,0, 0};


/*
 * imu update
 */
float g[5];
void imu_update(uint32_t T_ms, float *gyr, float *acc_cmss)
{	
	float norm;					/* normalization value */
	float norm_acc[XYZ];		/* normalization acceleration calue */
	float g_vector[XYZ];		/* The actual gravity vector in object coordinates */
	float g_vec_err[XYZ];		/* Error of actual gravity and accelerometer */
	static float vec_err_i[XYZ];/* error integral */
	
	float q0q0 = imu.w * imu.w; /* Some quaternion dot product that you need */
	float q0q1 = imu.w * imu.x;
	float q0q2 = imu.w * imu.y;
	float q0q3 = imu.w * imu.z;
	float q1q1 = imu.x * imu.x;
	float q1q2 = imu.x * imu.y;
	float q1q3 = imu.x * imu.z;
	float q2q2 = imu.y * imu.y;
	float q2q3 = imu.y * imu.z;
	float q3q3 = imu.z * imu.z;
	
	float T_s = T_ms * 0.001f;			/* Unit to second */
	float half_T_s = ((float)T_s / 2);	/* Half execution cycle(s) */

	/* 
	 * acceleration normalization 
	 * Consistent with quaternions
	 */
	norm = InvSqrt(POW(acc_cmss[X]) + POW(acc_cmss[Y]) + POW(acc_cmss[Z])); 
	norm_acc[X] = acc_cmss[X] * norm;
	norm_acc[Y] = acc_cmss[Y] * norm;
	norm_acc[Z] = acc_cmss[Z] * norm;
	
	/* 
	 * The actual gravity vector in geographic coordinates is converted to object coordinates
	 */
    g_vector[X] = 2 * (q1q3 - q0q2);
    g_vector[Y] = 2 * (q0q1 + q2q3);
    g_vector[Z] = 1-2*(q1q1 + q2q2);

	/*
	 * The gravity vector error is obtained by the cross product of the vector
	 */
    g_vec_err[X] = norm_acc[Y] * g_vector[Z] - norm_acc[Z] * g_vector[Y];
    g_vec_err[Y] = norm_acc[Z] * g_vector[X] - norm_acc[X] * g_vector[Z];
    g_vec_err[Z] = norm_acc[X] * g_vector[Y] - norm_acc[Y] * g_vector[X];

	/* 
	 * Integral of error 
	 */
	vec_err_i[X] += LIMIT(g_vec_err[X],-0.01f,0.01f) * G_KI * T_s;
	vec_err_i[Y] += LIMIT(g_vec_err[Y],-0.01f,0.01f) * G_KI * T_s;
	vec_err_i[Z] += LIMIT(g_vec_err[Z],-0.01f,0.01f) * G_KI * T_s;

	/*
	 * Complementary filter - P&I controller
	 */
	gyr[X] += g_vec_err[X] * G_KP + vec_err_i[X];
	gyr[Y] += g_vec_err[Y] * G_KP + vec_err_i[Y];
	gyr[Z] += g_vec_err[Z] * G_KP + vec_err_i[Z];
	
	/* 
	 * Update the Quaternion 
	 */
    imu.w = imu.w + (-imu.x*gyr[X] - imu.y*gyr[Y] - imu.z*gyr[Z]) * half_T_s;
    imu.x = imu.x + ( imu.w*gyr[X] - imu.z*gyr[Y] + imu.y*gyr[Z]) * half_T_s;
    imu.y = imu.y + ( imu.z*gyr[X] + imu.w*gyr[Y] - imu.x*gyr[Z]) * half_T_s;
    imu.z = imu.z + (-imu.y*gyr[X] + imu.x*gyr[Y] + imu.w*gyr[Z]) * half_T_s;

	/*
	 * Quaternion normalization : The normalized sum of squares is equal to 1 
	 */
	norm = InvSqrt(POW(imu.w) + POW(imu.x) + POW(imu.y) + POW(imu.z));
    imu.w *= norm;
    imu.x *= norm;
    imu.y *= norm;
    imu.z *= norm;

	/* calculating parameters */
	g[0] = g_vector[X];
    g[1] = g_vector[Y];
    g[2] = g_vector[Z];
	g[3] = 2*(q0q3 + q1q2); 
	g[4] = 1-2*(q2q2+q3q3);

	/* to avoid singularities */
	if(ABS(g_vector[Z]) > 0.05f)
		imu.is_singularity_pos = no;
	else
		imu.is_singularity_pos = yes;
}


/*
 * imu task
 * note : you need to read the original datas to buffer 
 * 		  interface that you set in axis_data.h first,
 * 		  and then call this function
 */
void imu_task(uint32_t T_ms)
{	
	imu_data_prepare(T_ms);
	imu_update(T_ms,axis.Gyr_rad,axis.Acc_cmss);
}


/*
 * angle calculate
 */
void angle_calculate(void)
{
	/* to avoid singularities */
	if(imu.is_singularity_pos == no)
	{
		/* arctanx = arcsin[x/(1+x^2)] */
		float gt = LIMIT(1-POW(g[0]),0,1);

		/* Calculated attitude Angle */
		imu.pit = fast_arctan(g[0],  gt ) * 57.30f; /* 1rad == 57.3deg */
		imu.rol = fast_arctan(g[1], g[2]) * 57.30f; 
		imu.yaw = fast_arctan(g[3], g[4]) * 57.30f; 
	}
}


