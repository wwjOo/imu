#ifndef __IMU_H_
#define __IMU_H_
#include "axis_data.h"


#define LIMIT(X,min,max) ((X <= min) ? min : ((X > max) ? max : X))


typedef enum
{
	no,
	yes,
} bool_e;

typedef struct
{	
	/* quaternion */
	float w;
	float x;
	float y;
	float z;
	
	/* attitude angle */
	float rol;
	float pit;
	float yaw;

	/* Whether the current is in the singularity position yes:1 / no:0 */
	bool_e is_singularity_pos;

} imu_t;


void imu_task(uint32_t T_ms);
void angle_calculate(void);


extern imu_t imu;


#endif



