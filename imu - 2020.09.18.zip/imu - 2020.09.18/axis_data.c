#include "axis_data.h"


axis_data_t axis;
calibrate_t calib;


/* 
 * static testing
 * if Gyr Original data > 50,then identified as non-static
 * static state 	: 1
 * non-static static: 0
 */

state_e static_testing(void)
{
	uint8_t i;

	for(i=0; i<XYZ; i++)
	{
		if(ABS(axis.gyr_original[i]) > 100)
		{
			return non_static;
		}
	}
	
	return in_static;
}


/* 
 * calibration 
 */
uint8_t func_cycle_time;	/* number of function executions */
uint8_t gyr_sum_time;		/* gyr calibrate cumulative frequency */
uint8_t acc_sum_time;		/* acc calibrate cumulative frequency */
int32_t sum_val[6];			/* accumulated value */

uint8_t acc_z_sum_time;
int32_t acc_z_sum_val[XYZ];

calib_state_e imu_data_calib(uint32_t T_ms)
{
	uint8_t i;
	state_e static_state = static_testing();
	
	if(calib.gyr_calib_flag || calib.acc_calib_flag || calib.acc_z_calib_flag)
	{
		/* do not calibrate when non-static or excessively titled */
		if(static_state == non_static || axis.acc_original[Z] < 2000)
		{
			/* reset all */
			gyr_sum_time = 0;
			acc_sum_time = 0;
			acc_z_sum_time = 0;

			for(i=0; i<XYZ; i++)
			{
				sum_val[G_X+i] = 0;
				sum_val[A_X+i] = 0;
				acc_z_sum_val[A_X+i] = 0;
			}
		}

		/* be executed per 50ms */
		if(func_cycle_time++ >= (50/T_ms))
		{
			func_cycle_time = 0;

			/* calibrate gyr */
			if(calib.gyr_calib_flag)
			{   
				for(i=0; i<XYZ; i++)
				{
					sum_val[G_X+i] += axis.gyr_original[X+i]; /* cumulative */
				}

				if(++gyr_sum_time >= CALIB_SUM_TIME_SET)
				{
					for(i=0; i<XYZ; i++) /* calculate the average */
					{
						calib.gyr_offset[X+i] = sum_val[G_X+i] / CALIB_SUM_TIME_SET;
						
						sum_val[G_X+i] = 0;
					}
					
					gyr_sum_time = 0;
					calib.gyr_calib_flag = 0; /* gyr calibrate finished */
				}
			}
			
			/* calibrate acc */
			if(calib.acc_calib_flag)
			{
				/* -1g <- when it is in static state,the acc value in Z axis is 1g */
				sum_val[A_X] += axis.acc_original[A_X];
				sum_val[A_Y] += axis.acc_original[A_Y];
				sum_val[A_Z] += axis.acc_original[A_Z] - ACC_1G_ADC_VALUE;
		
				if(++acc_sum_time >= CALIB_SUM_TIME_SET)
				{
					for(i=0 ;i<XYZ; i++)
					{
						calib.acc_offset[X+i] = sum_val[A_X+i] / CALIB_SUM_TIME_SET;
						
						sum_val[A_X+i] = 0;
					}
					
					acc_sum_time =0;
					calib.acc_calib_flag = 0;
				}	
			}

			/* calibrate acc z with another way */
			int16_t acc_average[XYZ+1];
			if((calib.gyr_calib_flag == 0 && calib.acc_calib_flag == 0) && calib.acc_z_calib_flag)
			{
				for(i=0; i<XYZ; i++)
				{
					/* Add up the values after the first calibration */
					acc_z_sum_val[X+i] += (axis.acc_original[X+i] - calib.acc_offset[X+i]); 
				}
				
				if(++acc_z_sum_time >= CALIB_SUM_TIME_SET)
				{
					for(i=0; i<XYZ; i++)
					{
						acc_average[X+i] = acc_z_sum_val[X+i] / CALIB_SUM_TIME_SET;
						
						acc_z_sum_val[X+i] = 0;
					}

					acc_z_sum_time = 0;
					calib.acc_z_calib_flag = 0;
					
					/* z axis acc calculated by x and y axis(The decomposition of the acceleration of gravity) */
					acc_average[Z+1] = Sqrt(POW(ACC_1G_ADC_VALUE) - (POW(acc_average[X]) + POW(acc_average[Y])));
					calib.acc_offset[Z] = acc_average[Z] - acc_average[Z+1];
				}
			}
		}
	}

	if(calib.gyr_calib_flag==0 && calib.acc_calib_flag==0 && calib.acc_z_calib_flag==0)
		return calib_ok;
	else
		return in_calib;
}


/* 
 * data prepare
 * return : calib state 
 */
float gyr_filter_last[XYZ];
float acc_filter_last[XYZ];

calib_state_e imu_data_prepare(uint32_t T_ms)
{	
	uint8_t i;
	calib_state_e calib_state;
	float axis_ref_val[6];
	float hz = (T_ms == 0) ? 0 : (1000.0f/(float)T_ms);

	/* get original data */
	axis.acc_original[X] = (((int16_t)ADC_DATA[0] << 8) | ADC_DATA[1]);/* gyr */
	axis.acc_original[Y] = (((int16_t)ADC_DATA[2] << 8) | ADC_DATA[3]);
	axis.acc_original[Z] = (((int16_t)ADC_DATA[4] << 8) | ADC_DATA[5]);

	axis.Temp_Original   = (((int16_t)ADC_DATA[6] << 8) | ADC_DATA[7]);/* temperature */
	axis.Temp = axis.Temp_Original/326.8f + 25;
 
	axis.gyr_original[X] = (((int16_t)ADC_DATA[ 8]<< 8) |ADC_DATA[ 9]);/* acc */
	axis.gyr_original[Y] = (((int16_t)ADC_DATA[10]<< 8) |ADC_DATA[11]);
	axis.gyr_original[Z] = (((int16_t)ADC_DATA[12]<< 8) |ADC_DATA[13]);
	
	/* original data calibration */
	calib_state = imu_data_calib(T_ms);
	
	/* get ref data */
	for(i=0; i<XYZ; i++)
	{ 
		axis_ref_val[A_X+i] = axis.acc_original[X+i] - calib.acc_offset[X+i];
		axis_ref_val[G_X+i] = axis.gyr_original[X+i] - calib.gyr_offset[X+i];
	}

	/* LPF(lowpass filtering) */
	for(i=0; i<XYZ; i++)
	{
		axis.Gyr_filter[X+i] += 0.12f * (axis_ref_val[G_X+i] - gyr_filter_last[X+i]);
		axis.Acc_filter[X+i] += 0.12f * (axis_ref_val[A_X+i] - acc_filter_last[X+i]);			
	}

	/* get gyr a(rad/s2) */
	for(i=0; i<XYZ; i++)
	{
		axis.gyr_rad_v[i] = axis.Gyr_filter[X+i] * GYR_ADC_TO_RAD_P_S;
		axis.gyr_rad_a[i] = hz * (axis.gyr_rad_v[i] - axis.gyr_rad_v_old[i]);
		axis.gyr_rad_v_old[i] = axis.gyr_rad_v[i];
	}

	/* 	get x 		   	   	get y 	   	    	get z 																										
	/*  z   x	*/		/*  x   y	*/		/*  y   z	*/
    /*	|  /    */      /*	|  /    */      /*	|  /    */
    /*	| /     */      /*	| /     */      /*	| /     */
    /*	|/      */      /*	|/      */      /*	|/      */
    /* 	— — — y */      /* 	— — — z */      /* 	— — — x */
	/* get centripetal acceleration  (a = (angle)a × R) 
	/* when the accelerometer is not at the zero point of the body coordinate */
	axis.centri_a[X] = axis.gyr_rad_a[Z] * CENTER_OFFSET_Y;
	axis.centri_a[Y] = axis.gyr_rad_a[X] * CENTER_OFFSET_Z;
	axis.centri_a[Z] = axis.gyr_rad_a[Y] * CENTER_OFFSET_X;
	
	/* record */
	for(i=0; i<XYZ; i++)
	{
		gyr_filter_last[X+i] = axis.Gyr_filter[X+i];
		acc_filter_last[X+i] = axis.Acc_filter[X+i] - axis.centri_a[X+i] / ACC_ADC_TO_CM_P_SS;
	}
	
	/* unit change */
	for(i=0; i<3; i++)
	{
		/* gyr deg/s */
		axis.Gyr_deg[i] = axis.Gyr_filter[X+i] * GYR_ADC_TO_DEG_P_S;
		/* gyr rad/s */
		axis.Gyr_rad[i] = axis.Gyr_filter[X+i] * GYR_ADC_TO_RAD_P_S;
		/* acc cm/s2 */
		axis.Acc_cmss[i]= axis.Acc_filter[X+i] * ACC_ADC_TO_CM_P_SS;
	}

	return calib_state;
}




/***************************some mathematical formula************************/
/***************************some mathematical formula************************/
float InvSqrt(float x)
{
	float xhalf = 0.5f*x;
	int i = *(int*)&x;	// get bits for floating VALUE
	
	i = 0x5f375a86 - (i>>1);
	x = *(float*)&i;
	x = x * (1.5f - xhalf*x*x);
	
	return x;
}

float Sqrt(float x)
{
	return x * InvSqrt(x);
}

const float fast_arctan_table[257] =
{
	0.000000e+00, 3.921549e-03, 7.842976e-03, 1.176416e-02,
	1.568499e-02, 1.960533e-02, 2.352507e-02, 2.744409e-02,
	3.136226e-02, 3.527947e-02, 3.919560e-02, 4.311053e-02,
	4.702413e-02, 5.093629e-02, 5.484690e-02, 5.875582e-02,
	6.266295e-02, 6.656816e-02, 7.047134e-02, 7.437238e-02,
	7.827114e-02, 8.216752e-02, 8.606141e-02, 8.995267e-02,
	9.384121e-02, 9.772691e-02, 1.016096e-01, 1.054893e-01,
	1.093658e-01, 1.132390e-01, 1.171087e-01, 1.209750e-01,
	1.248376e-01, 1.286965e-01, 1.325515e-01, 1.364026e-01,
	1.402496e-01, 1.440924e-01, 1.479310e-01, 1.517652e-01,
	1.555948e-01, 1.594199e-01, 1.632403e-01, 1.670559e-01,
	1.708665e-01, 1.746722e-01, 1.784728e-01, 1.822681e-01,
	1.860582e-01, 1.898428e-01, 1.936220e-01, 1.973956e-01,
	2.011634e-01, 2.049255e-01, 2.086818e-01, 2.124320e-01,
	2.161762e-01, 2.199143e-01, 2.236461e-01, 2.273716e-01,
	2.310907e-01, 2.348033e-01, 2.385093e-01, 2.422086e-01,
	2.459012e-01, 2.495869e-01, 2.532658e-01, 2.569376e-01,
	2.606024e-01, 2.642600e-01, 2.679104e-01, 2.715535e-01,
	2.751892e-01, 2.788175e-01, 2.824383e-01, 2.860514e-01,
	2.896569e-01, 2.932547e-01, 2.968447e-01, 3.004268e-01,
	3.040009e-01, 3.075671e-01, 3.111252e-01, 3.146752e-01,
	3.182170e-01, 3.217506e-01, 3.252758e-01, 3.287927e-01,
	3.323012e-01, 3.358012e-01, 3.392926e-01, 3.427755e-01,
	3.462497e-01, 3.497153e-01, 3.531721e-01, 3.566201e-01,
	3.600593e-01, 3.634896e-01, 3.669110e-01, 3.703234e-01,
	3.737268e-01, 3.771211e-01, 3.805064e-01, 3.838825e-01,
	3.872494e-01, 3.906070e-01, 3.939555e-01, 3.972946e-01,
	4.006244e-01, 4.039448e-01, 4.072558e-01, 4.105574e-01,
	4.138496e-01, 4.171322e-01, 4.204054e-01, 4.236689e-01,
	4.269229e-01, 4.301673e-01, 4.334021e-01, 4.366272e-01,
	4.398426e-01, 4.430483e-01, 4.462443e-01, 4.494306e-01,
	4.526070e-01, 4.557738e-01, 4.589307e-01, 4.620778e-01,
	4.652150e-01, 4.683424e-01, 4.714600e-01, 4.745676e-01,
	4.776654e-01, 4.807532e-01, 4.838312e-01, 4.868992e-01,
	4.899573e-01, 4.930055e-01, 4.960437e-01, 4.990719e-01,
	5.020902e-01, 5.050985e-01, 5.080968e-01, 5.110852e-01,
	5.140636e-01, 5.170320e-01, 5.199904e-01, 5.229388e-01,
	5.258772e-01, 5.288056e-01, 5.317241e-01, 5.346325e-01,
	5.375310e-01, 5.404195e-01, 5.432980e-01, 5.461666e-01,
	5.490251e-01, 5.518738e-01, 5.547124e-01, 5.575411e-01,
	5.603599e-01, 5.631687e-01, 5.659676e-01, 5.687566e-01,
	5.715357e-01, 5.743048e-01, 5.770641e-01, 5.798135e-01,
	5.825531e-01, 5.852828e-01, 5.880026e-01, 5.907126e-01,
	5.934128e-01, 5.961032e-01, 5.987839e-01, 6.014547e-01,
	6.041158e-01, 6.067672e-01, 6.094088e-01, 6.120407e-01,
	6.146630e-01, 6.172755e-01, 6.198784e-01, 6.224717e-01,
	6.250554e-01, 6.276294e-01, 6.301939e-01, 6.327488e-01,
	6.352942e-01, 6.378301e-01, 6.403565e-01, 6.428734e-01,
	6.453808e-01, 6.478788e-01, 6.503674e-01, 6.528466e-01,
	6.553165e-01, 6.577770e-01, 6.602282e-01, 6.626701e-01,
	6.651027e-01, 6.675261e-01, 6.699402e-01, 6.723452e-01,
	6.747409e-01, 6.771276e-01, 6.795051e-01, 6.818735e-01,
	6.842328e-01, 6.865831e-01, 6.889244e-01, 6.912567e-01,
	6.935800e-01, 6.958943e-01, 6.981998e-01, 7.004964e-01,
	7.027841e-01, 7.050630e-01, 7.073330e-01, 7.095943e-01,
	7.118469e-01, 7.140907e-01, 7.163258e-01, 7.185523e-01,
	7.207701e-01, 7.229794e-01, 7.251800e-01, 7.273721e-01,
	7.295557e-01, 7.317307e-01, 7.338974e-01, 7.360555e-01,
	7.382053e-01, 7.403467e-01, 7.424797e-01, 7.446045e-01,
	7.467209e-01, 7.488291e-01, 7.509291e-01, 7.530208e-01,
	7.551044e-01, 7.571798e-01, 7.592472e-01, 7.613064e-01,
	7.633576e-01, 7.654008e-01, 7.674360e-01, 7.694633e-01,
	7.714826e-01, 7.734940e-01, 7.754975e-01, 7.774932e-01,
	7.794811e-01, 7.814612e-01, 7.834335e-01, 7.853983e-01,
	7.853983e-01
};

#define TAN_MAP_SIZE    256
#define TAN_MAP_RES     0.003921569f     /* (smallest non-zero value in table) */

float fast_arctan(float y, float x)
{
	float x_abs, y_abs, z;
	float alpha, angle, base_angle;
	int index;

	/* don't divide by zero! */
	if ((y == 0.0f) || (x == 0.0f))
	{
		angle = 0.0f;
	}
	else 
	{
		/* normalize to +/- 45 degree range */
		y_abs = ABS(y);
		x_abs = ABS(x);
		z = ((y_abs < x_abs) ? (y_abs / x_abs) : (x_abs / y_abs));
		
		/* when ratio approaches the table resolution, the angle is */
		/*      best approximated with the argument itself...       */
		if(z < TAN_MAP_RES)
		{
			base_angle = z;
		}
		else 
		{
			/* find index and interpolation value */
			alpha = z * (float)TAN_MAP_SIZE - 0.5f;
			index = (int)alpha;
			alpha -= (float)index;
			
			/* determine base angle based on quadrant and */
			/* add or subtract table value from base angle based on quadrant */
			base_angle = fast_arctan_table[index];
			base_angle += (fast_arctan_table[index + 1] - fast_arctan_table[index]) * alpha;
		}

		if(x_abs > y_abs) 
		{   /* -45 -> 45 or 135 -> 225 */
			if(x >= 0.0f) 
			{   /* -45 -> 45 */
				if(y >= 0.0f)
					angle = base_angle;   /* 0 -> 45, angle OK */
				else
					angle = -base_angle;  /* -45 -> 0, angle = -angle */
			} 
			else
			{	/* 135 -> 180 or 180 -> -135 */
				angle = 3.1415926535f;

				if(y >= 0.0f)
					angle -= base_angle;  /* 135 -> 180, angle = 180 - angle */
				else
					angle = base_angle - angle;   /* 180 -> -135, angle = angle - 180 */
			}
		} 
		else 
		{	/* 45 -> 135 or -135 -> -45 */
			if(y >= 0.0f) 
			{	/* 45 -> 135 */
				angle = 1.5707963267f;

				if(x >= 0.0f)
					angle -= base_angle;  /* 45 -> 90, angle = 90 - angle */
				else
					angle += base_angle;  /* 90 -> 135, angle = 90 + angle */
			} 
			else
			{	/* -135 -> -45 */
				angle = -1.5707963267f;

				if(x >= 0.0f)
					angle += base_angle;  /* -90 -> -45, angle = -90 + angle */
				else
					angle -= base_angle;  /* -135 -> -90, angle = -90 - angle */
			}
		}
	}

	return angle;
}




