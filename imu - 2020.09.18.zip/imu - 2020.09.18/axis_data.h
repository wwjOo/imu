#ifndef __AXIS_DATA_H_
#define __AXIS_DATA_H_

/*
 * ! ! ! please read the follow informations first ! ! !
 * ! ! ! please read the follow informations first ! ! !
 * ! ! ! please read the follow informations first ! ! !
 * 
 * You just fill in some informations below and 
 * call imu_update function in imu.c,then you can use it.
 * but first you should read the original dates first.
 * if the angle data is not zero when put the body horizontal,
 * you should set the follow first:
 * 	axis.gyr_calib_flag = 1;
 *  axis.acc_calib_flag = 1;
 *  axis.acc_z_calib_flag = 1;
 * note : Ensure the accuracy of the execution cycle data for the imu_update function in imu.c
 */
/*****************************************************************************************/
#include "icm.h"					/* your file in which the buf variable resides */
#define ADC_DATA		mpu_buffer 	/* your buf variable reading from sensor */
#define GYR_RANGE		2000 		/* the gyr Full-Scale Range you set(+-) */
#define ACC_RANGE		16			/* the acc Full-Scale Range you set(+-) */
#define CENTER_OFFSET_X	0			/* The distance of the sensor from the center of the body */
#define CENTER_OFFSET_Y	0			/* The distance of the sensor from the center of the body */
#define CENTER_OFFSET_Z	0			/* The distance of the sensor from the center of the body */
/*****************************************************************************************/


#define ACC_1G_ADC_VALUE	(65536 / (ACC_RANGE*2))

#define GYR_ADC_TO_DEG_P_S	((float)(GYR_RANGE*2) / 65536.0f)
#define DEG_TO_RAD			0.017453f
#define GYR_ADC_TO_RAD_P_S	(GYR_ADC_TO_DEG_P_S * DEG_TO_RAD)

#define ACC_ADC_TO_M_P_SS	((float)(ACC_RANGE*2) / 65536.0f)
#define MSS_TO_CMSS			100.0f
#define ACC_ADC_TO_CM_P_SS	(ACC_ADC_TO_M_P_SS * MSS_TO_CMSS)

#define CALIB_SUM_TIME_SET 	50 /* accumulate time (max:8bit (255)) */

#define ABS(X) ((X > 0) ? X : -X)
#define POW(X) (X * X)


typedef signed char         int8_t;
typedef signed short        int16_t;
typedef signed int          int32_t;
typedef unsigned char       uint8_t;
typedef unsigned short      uint16_t;
typedef unsigned int        uint32_t;
typedef unsigned long long  uint64_t;


enum
{
	X=0,
	Y,
	Z,
	XYZ,
};

enum
{
	A_X=0,
	A_Y,
	A_Z,
	G_X,
	G_Y,
	G_Z,
};


typedef struct
{	
	/* original adc data  */
	int16_t acc_original[XYZ];
	int16_t gyr_original[XYZ];

	/* temperature */
	int16_t Temp_Original;
	float Temp;

	/* filter data */
	float Acc_filter[XYZ];
	float Gyr_filter[XYZ];

	float gyr_rad_v[XYZ];
	float gyr_rad_v_old[XYZ];
	float gyr_rad_a[XYZ];
	float centri_a[XYZ];	/* centripetal acceleration */
	
	float Gyr_deg[XYZ];
	float Gyr_rad[XYZ];
	float Acc_cmss[XYZ];
	
} axis_data_t;

typedef struct
{
	/* calibrate flag */
	uint8_t acc_calib_flag;		/* calibrate acc */
	uint8_t gyr_calib_flag;		/* calibrate gyr */
	uint8_t acc_z_calib_flag;	/* Calibrate the Z axis of ACC */
	
	/* calibrate data */
	int16_t acc_offset[XYZ];
	int16_t gyr_offset[XYZ];

} calibrate_t;


typedef enum{
	in_static,
	non_static,
} state_e;

typedef enum{
	in_calib,
	calib_ok,
} calib_state_e;


calib_state_e imu_data_prepare(uint32_t T_ms);

float InvSqrt(float x);
float Sqrt(float x);
float fast_arctan(float y, float x);


extern axis_data_t axis;
extern calibrate_t calib;


#endif




